package com;

import java.io.File;
import java.io.IOException;

public class CreateFileDemo {
	
	public static void main(String[] args) {
        try {
            // Specify the file path
            String filePath = "example.txt";
            
            // Create a File object
            File file = new File(filePath);
            
            // Check if the file doesn't exist, then create it
            if (file.createNewFile()) {
                System.out.println("File created successfully");
            } else {
                System.out.println("File already exists");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

}
