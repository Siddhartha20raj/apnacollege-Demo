package com;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileDemo {
	
	public static void main(String[] args) {
        try {
            // Specify the file path
            String filePath = "example.txt";
            
            // Create a FileReader object
            FileReader fileReader = new FileReader(filePath);
            
            // Create a BufferedReader object
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            // Read and print each line from the file
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            
            // Close the BufferedReader
            bufferedReader.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

}
