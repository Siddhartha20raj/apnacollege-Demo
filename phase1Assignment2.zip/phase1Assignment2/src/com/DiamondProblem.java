package com;

interface A {
    void display();
}

interface B extends A {
    void show();
}

interface C extends A {
    void print();
}

class D implements B, C {
    @Override
    public void display() {
        System.out.println("Implemented display method in class D");
    }

    @Override
    public void show() {
        System.out.println("Implemented show method in class D");
    }

    @Override
    public void print() {
        System.out.println("Implemented print method in class D");
    }
}

public class DiamondProblem {
	
	public static void main(String[] args) {
        D d = new D();
        d.display();
        d.show();
        d.print();
    }

}
