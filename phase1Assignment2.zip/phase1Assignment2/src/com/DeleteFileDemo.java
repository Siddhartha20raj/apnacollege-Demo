package com;

import java.io.File;

public class DeleteFileDemo {
	
	public static void main(String[] args) {
        // Specify the file path
        String filePath = "example.txt";
        
        // Create a File object
        File file = new File(filePath);
        
        // Check if the file exists, then delete it
        if (file.exists()) {
            if (file.delete()) {
                System.out.println("File deleted successfully");
            } else {
                System.out.println("Unable to delete the file");
            }
        } else {
            System.out.println("File does not exist");
        }
    }

}
