package com;

import java.io.FileWriter;
import java.io.IOException;

public class UpdateFileDemo {
	
	public static void main(String[] args) {
        try {
            // Specify the file path
            String filePath = "example.txt";
            
            // Create a FileWriter object with append mode
            FileWriter fileWriter = new FileWriter(filePath, true);
            
            // Write data to the file
            fileWriter.write("\nThis line is added for update");
            
            // Close the FileWriter
            fileWriter.close();
            
            System.out.println("File updated successfully");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

}
