package com;

class Shape {
    // Method to calculate area (to be overridden by subclasses)
    double calculateArea() {
        return 0.0;
    }
}

// Subclass 1: Circle
class Circle extends Shape {
    double radius;

    // Constructor
    Circle(double radius) {
        this.radius = radius;
    }

    // Method overriding
    @Override
    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

// Subclass 2: Rectangle
class Rectangle extends Shape {
    double length;
    double width;

    // Constructor
    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Method overriding
    @Override
    double calculateArea() {
        return length * width;
    }
}

public class PolymorphismDemo {
	
	public static void main(String[] args) {
        // Polymorphic behavior using an array of shapes
        Shape[] shapes = new Shape[3];
        shapes[0] = new Circle(5.0);
        shapes[1] = new Rectangle(4.0, 6.0);
        shapes[2] = new Circle(3.0);

        // Calculate and display areas
        for (Shape shape : shapes) {
            System.out.println("Area: " + shape.calculateArea());
        }
    }
}
