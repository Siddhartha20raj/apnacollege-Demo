package com;

public class MyClass {
	
	// Member variables
    private int number;

    // Constructor
    public MyClass(int number) {
        this.number = number;
    }

    // Getter method
    public int getNumber() {
        return number;
    }

    // Main method
    public static void main(String[] args) {
        // Creating an object of MyClass
        MyClass myObject = new MyClass(10);

        // Accessing the member variable using a getter method
        System.out.println("Number: " + myObject.getNumber());
    }

}
