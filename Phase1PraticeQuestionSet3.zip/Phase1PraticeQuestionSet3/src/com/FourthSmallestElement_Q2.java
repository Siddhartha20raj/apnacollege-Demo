package com;

import java.util.*;

public class FourthSmallestElement_Q2 {
	
	 public static int findFourthSmallest(int[] nums) {
	        // Check if the array has at least four elements
	        if (nums.length < 4) {
	            System.out.println("Array should have at least four elements");
	            return -1; // Return a default value or handle the case as needed
	        }

	        // Sort the array in ascending order
	        Arrays.sort(nums);

	        // Return the fourth element (index 3 in zero-based indexing)
	        return nums[3];
	    }

	    public static void main(String[] args) {
	        int[] numbers = {9, 2, 7, 4, 1, 8, 5, 6, 3};

	        int fourthSmallest = findFourthSmallest(numbers);

	        if (fourthSmallest != -1) {
	            System.out.println("The fourth smallest element is: " + fourthSmallest);
	        }
	    }

}
