package com;

public class RightRotateArray_Q1 {
	
	public static void main(String[] args) {
        // Example array
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        System.out.println("Original Array:");
        printArray(arr);

        // Right rotate the array
        rightRotateArray(arr, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps:");
        printArray(arr);
    }

    // Function to right rotate the array by 'steps' steps
    private static void rightRotateArray(int[] arr, int steps) {
        int n = arr.length;
        steps = steps % n; // Handle cases where steps > array length

        // Create a temporary array to store the rotated elements
        int[] temp = new int[n];

        // Copy the last 'steps' elements to the temporary array
        System.arraycopy(arr, n - steps, temp, 0, steps);

        // Shift the remaining elements to the right
        System.arraycopy(arr, 0, arr, steps, n - steps);

        // Copy the rotated elements back to the original array
        System.arraycopy(temp, 0, arr, 0, steps);
    }

    // Function to print the elements of an array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

}
