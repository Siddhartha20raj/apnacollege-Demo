package com;

import java.util.Stack;

public class StackExample_Q8 {
	
	public static void main(String[] args) {
		Stack ss = new Stack();
		System.out.println("Empty "+ss.empty());
		ss.push(100);
		ss.push(200);
		ss.push(300);
		ss.push(400);
		System.out.println("Empty "+ss.empty());
		System.out.println(ss);
		System.out.println("Remove "+ss.pop());		// remove and display 
		System.out.println(ss);
		System.out.println("Search top most element "+ss.peek());	// display top most element 
		
		}

}
