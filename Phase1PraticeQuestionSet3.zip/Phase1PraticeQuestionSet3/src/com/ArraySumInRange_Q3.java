package com;
import java.util.Scanner;
public class ArraySumInRange_Q3 {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the size of the array
        System.out.print("Enter the size of the array: ");
        int n = scanner.nextInt();

        // Input array elements
        int[] arr = new int[n];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + i + ": ");
            arr[i] = scanner.nextInt();
        }

        // Input the range [L, R]
        System.out.print("Enter the value of L (0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        System.out.print("Enter the value of R (0 <= L <= R <= n-1): ");
        int R = scanner.nextInt();

        // Validate the range
        if (L < 0 || R < L || R >= n) {
            System.out.println("Invalid range. Please make sure 0 <= L <= R <= n-1.");
            return;
        }

        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        // Output the result
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }

}
