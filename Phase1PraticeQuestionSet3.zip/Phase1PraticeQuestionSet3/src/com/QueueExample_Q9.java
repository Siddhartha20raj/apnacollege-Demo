package com;

import java.util.*;

public class QueueExample_Q9 {
	public static void main(String[] args) {
        // Create a Queue using LinkedList
        Queue<String> queue = new LinkedList<>();

        // Insert elements into the queue
        enqueue(queue, "Element 1");
        enqueue(queue, "Element 2");
        enqueue(queue, "Element 3");

        // Display the elements in the queue
        System.out.println("Queue elements: " + queue);

        // Remove elements from the queue
        String removedElement = dequeue(queue);
        System.out.println("Removed element: " + removedElement);

        // Display the updated queue
        System.out.println("Updated Queue elements: " + queue);
    }

    // Method to insert an element into the queue
    private static void enqueue(Queue<String> queue, String element) {
        queue.add(element);
        System.out.println("Enqueued: " + element);
    }

    // Method to remove an element from the queue
    private static String dequeue(Queue<String> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return null;
        }
        return queue.poll();
    }


}
