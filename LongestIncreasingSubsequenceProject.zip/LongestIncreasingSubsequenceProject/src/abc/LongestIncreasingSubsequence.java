package abc;

import java.util.*;

public class LongestIncreasingSubsequence {
	 public static void main(String[] args) {
	        // Sample input: replace this list with your random numbers
	        List<Integer> numbers = Arrays.asList(10, 22, 9, 33, 21, 50, 41, 60, 80);

	        // Find and print the longest increasing subsequence
	        List<Integer> lis = findLongestIncreasingSubsequence(numbers);
	        System.out.println("Longest Increasing Subsequence: " + lis);
	    }

	    // Function to find the longest increasing subsequence
	    public static List<Integer> findLongestIncreasingSubsequence(List<Integer> numbers) {
	        int n = numbers.size();

	        // Initialize an array to store the length of the longest increasing subsequence
	        int[] lisLength = new int[n];
	        Arrays.fill(lisLength, 1);

	        // Compute the length of the LIS
	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	                if (numbers.get(i) > numbers.get(j) && lisLength[i] < lisLength[j] + 1) {
	                    lisLength[i] = lisLength[j] + 1;
	                }
	            }
	        }

	        // Find the maximum value in lisLength array
	        int maxLength = Arrays.stream(lisLength).max().orElse(1);

	        // Find the elements in the LIS using the lisLength array
	        List<Integer> lis = new ArrayList<>();
	        for (int i = n - 1; i >= 0; i--) {
	            if (lisLength[i] == maxLength) {
	                lis.add(numbers.get(i));
	                maxLength--;
	            }
	        }

	        // Reverse the LIS to get the correct order
	        List<Integer> reversedLis = new ArrayList<>();
	        for (int i = lis.size() - 1; i >= 0; i--) {
	            reversedLis.add(lis.get(i));
	        }

	        return reversedLis;
	    }
}
