package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AuthenticationClassTest {

    private AuthenticationClass authClass;

    @BeforeEach
    void setUp() {
        authClass = new AuthenticationClass();
    }

    @Test
    void testAuthenticateUser_Success() {
        assertTrue(authClass.authenticateUser("akash", "akash123"));
    }

    @Test
    void testAuthenticateUser_Failure_InvalidPassword() {
        assertFalse(authClass.authenticateUser("raj", "raj@123"));
    }

    @Test
    void testAuthenticateUser_Failure_InvalidUsername() {
        assertFalse(authClass.authenticateUser("nonExistentUser", "somePassword"));
    }

    @Test
    void testAuthenticateUser_Failure_NullUsername() {
        assertFalse(authClass.authenticateUser(null, "password123"));
    }

    @Test
    void testAuthenticateUser_Failure_NullPassword() {
        assertFalse(authClass.authenticateUser("johnDoe", null));
    }

    // Additional test cases can be added based on your requirements

    // Example of testing a scenario where the user database is empty
    @Test
    void testAuthenticateUser_Failure_EmptyUserDatabase() {
        AuthenticationClass emptyAuthClass = new AuthenticationClass();
        assertFalse(emptyAuthClass.authenticateUser("anyUser", "anyPassword"));
    }
}