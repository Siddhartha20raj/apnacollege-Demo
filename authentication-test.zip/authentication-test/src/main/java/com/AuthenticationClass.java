package com;

import java.util.HashMap;
import java.util.Map;

public class AuthenticationClass {

    // Simulated user database
    private static final Map<String, String> userDatabase = new HashMap<>();

    // Constructor to initialize some sample users
    public AuthenticationClass() {
        userDatabase.put("akash", "akash@123");
        userDatabase.put("raj", "raj@123");
        // Add more users as needed
    }

    /**
     * Authenticates a user based on the provided username and password.
     *
     * @param username The username to authenticate.
     * @param password The password to authenticate.
     * @return true if the authentication is successful, false otherwise.
     */
    public boolean authenticateUser(String username, String password) {
        // Check if the user exists in the database
        if (userDatabase.containsKey(username)) {
            // Check if the provided password is not null and matches the stored password
            String storedPassword = userDatabase.get(username);
            return password != null && password.equals(storedPassword);
        }
        // User not found
        return false;
    }
}
