package com;

import java.util.Scanner;

public class AuthenticationConsoleApp {

    public static void main(String[] args) {
        AuthenticationClass authenticationClass = new AuthenticationClass();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Authentication Console App!");

        // Get username and password from the user
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // Authenticate user
        boolean isAuthenticated = authenticationClass.authenticateUser(username, password);

        // Display authentication result
        if (isAuthenticated) {
            System.out.println("Authentication successful. Welcome, " + username + "!");
        } else {
            System.out.println("Authentication failed. Invalid username or password.");
        }

        // Close the scanner
        scanner.close();
    }
}
