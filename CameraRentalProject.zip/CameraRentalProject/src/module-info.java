/**
 * 
 */
/**
 * 
 */
module CameraRentalProject {
}