package com.cemerarental.main;
import java.util.*;
import com.cemerarental.utitlity.CameraRentalUtility;

public class App {
	
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		System.out.println("+----------------------------------+");
		System.out.println("|   Welcome to Camera Rental App   |");
		System.out.println("+----------------------------------+");
		System.out.println("PLEASE LOGIN TO CONTINUE -");
		CameraRentalUtility.login();
	}


}
