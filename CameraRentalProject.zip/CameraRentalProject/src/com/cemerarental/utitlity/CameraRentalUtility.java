package com.cemerarental.utitlity;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import com.camerarental.service.CameraService;

public class CameraRentalUtility {

    static Scanner sc = new Scanner(System.in);

    private static Map<String, String> customerCredentials = new HashMap<>();

    static {
        customerCredentials.put("Amrit@gmail.com", "Amrit@123");
        customerCredentials.put("Ayush@gmail.com", "Ritu@123");
    }

    public static void login() {
        System.out.println("Enter your emailid ");
        String emailid = sc.next();
        System.out.println("Enter your password ");
        String password = sc.next();

        if (emailid.equals("admin") && password.equals("admin123")) {
            System.out.println("Successfully login as Admin");
            mainOption();
        } else if (validateCustomerLogin(emailid, password)) {
            System.out.println("Successfully login as Customer");
            mainOption();
        } else {
            System.out.println("Failure, try once again");
        }
    }

    private static boolean validateCustomerLogin(String email, String password) {
        return customerCredentials.containsKey(email) && customerCredentials.get(email).equals(password);
    }

    private static void mainOption() {
        int choice;
        String con = "";
        CameraService cs = new CameraService();
        do {
            System.out.println("1: My Camera");
            System.out.println("2: Rent Camera");
            System.out.println("3: View All Camera");
            System.out.println("4: My Wallet");
            System.out.println("5: Exit");
            System.out.println("Plz enter your choice");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    subMenuOption();
                    break;
                case 2:
                    cs.rentCamera();
                    break;
                case 3:
                    cs.viewAllCamera();
                    break;
                case 4:
                    cs.myWallet();
                    break;
                case 5:
                    System.out.println("Exiting the application. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Wrong choice");
                    break;
            }
            System.out.println("Do you want to continue(y/n)");
            con = sc.next();
        } while (con.equalsIgnoreCase("y"));
    }

    private static void subMenuOption() {
        int choice;
        String con = "";
        CameraService cs = new CameraService();
        do {
            System.out.println("1: Add Camera");
            System.out.println("2: Remove Camera");
            System.out.println("3: View Camera details");
            System.out.println("4: Go to Previous Menu");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    cs.addCamera();
                    break;
                case 2:
                    cs.removeCamera();
                    break;
                case 3:
                    cs.viewAllCamera();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Wrong choice");
                    break;
            }
            System.out.println("Do you want to continue(y/n)");
            con = sc.next();
        } while (con.equalsIgnoreCase("y"));
    }
}
