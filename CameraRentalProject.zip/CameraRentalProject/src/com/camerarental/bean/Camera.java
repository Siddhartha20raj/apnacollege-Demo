package com.camerarental.bean;

public class Camera {
    private int index;
    private String brand;
    private String model;
    private float perDayPrice;
    private String availability;

    public Camera() {
    }

    public Camera(int index, String brand, String model, float perDayPrice, String availability) {
        this.index = index;
        this.brand = brand;
        this.model = model;
        this.perDayPrice = perDayPrice;
        this.availability = availability;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public float getPerDayPrice() {
        return perDayPrice;
    }

    public void setPerDayPrice(float perDayPrice) {
        this.perDayPrice = perDayPrice;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    @Override
    public String toString() {
        return "Camera [index=" + index + ", brand=" + brand + ", model=" + model + ", perDayPrice=" + perDayPrice
                + ", availability=" + availability + "]";
    }
}
