package com.bean;

public class Employee {

}
